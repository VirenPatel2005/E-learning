visit counts
0-homepage     php
1-course pages php
2-aboutus page