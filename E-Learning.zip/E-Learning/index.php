
<?php
    session_start();
?>
<!-- <form action="home2.php" method="get">
    Name<input type="text" name="fname"><br>    
    password<input type="text" name="pwd"><br>
    <input type="submit">
</form> -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<!--  -->

<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans|Candal|Alegreya+Sans">
  <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/imagehover.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
<style>

    .card
    {
        /* position: relative;  */
        margin-top:100px;
    }
    a,a:hover
    {
        text-decoration: none;
        color: white;
    }
      body
    {
        background: url('background.jpg') no-repeat;
    }
</style>
<body><center>
<div class="card text-center" style="width: 30rem; height: 30rem; background-color:#18A558;">
  <div class="card-body" style="margin-top:5rem;">
    <!-- <h5 class="card-title">Card title</h5> -->
    <h6 class="card-subtitle mb-2 text-muted" style="font-size:4rem;">E-Learning</h6>
    <p class="card-text" style="font-size:2rem;">Welcome to E-Learning if you are new please Sign-In </p>

    <a href="#login" data-target="#login" data-toggle="modal">
    <button class="btn btn-primary" style="width: 10rem; height: 5rem; font-size:1.5rem;">
  <li>
      Login as 
    </li>
  </button>          
</a>      
         
<a href="#signin" data-target="#signin" data-toggle="modal">
<button class="btn btn-warning" style="width: 10rem; height: 5rem; font-size:1.5rem;">
  <li>
      Sign-In
    </li>        
  </button>
</a>      
  </div>
</div>
</center>

<div class="modal" id="login" role="dialog">
    <div class="modal-dialog modal-sm">
      <!-- Modal content no 1-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title text-center form-title" style="color:white;">Login</h4>
        </div>
        <div class="modal-body padtrbl">
          <div class="login-box-body">
            <p class="login-box-msg">Log in to start your session</p>
            <div class="form-group">
              <form  id="loginForm" action="index.php" method="get" >
                <div class="form-group has-feedback">
                  <!----- username -------------->
                  <input class="form-control" placeholder="Username" id="loginid" type="text" autocomplete="off" name="fname"/>
                  <span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 27px; top: 5px;" id="span_loginid"></span>
                  <!---Alredy exists  ! -->
                  <span class="glyphicon glyphicon-user form-control-feedback" style="background-color: rgb(230,230,230);"></span>
                </div>
                <div class="form-group has-feedback">
                  <!----- password -------------->
                  <input class="form-control" placeholder="Password" id="loginpsw" type="password" autocomplete="off" name="pwd"/>
                  <span style="display:none;font-weight:bold; position:absolute;color: grey;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 27px; top: 5px;" id="span_loginpsw"></span>
                  <!---Alredy exists  ! -->
                  <span class="glyphicon glyphicon-lock form-control-feedback" style="background-color: rgb(230,230,230);"></span>
                </div>
                <div class="row">
                  <div class="col-xs-12">
                    <div class="checkbox icheck">
                      <label>
                                <input type="checkbox" id="loginrem" > Remember Me
                              </label>
                    </div>
                  </div>
                  <div class="col-xs-12">
                    <button type="submit " class="btn btn-green btn-block btn-flat btn btn-primary">Log In</button>
                  </div><br>
                  <div style="margin-left: 2rem;">
                    <p>don't have account click-><a href="#signin" data-target="#signin" data-toggle="modal" style="color: black;">Sign in</a></p>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>

  <!--  -->

  <div class="modal fade" id="signin" role="dialog">
    <div class="modal-dialog modal-sm">

      <!-- Modal content no 1-->
      <div class="modal-content">
        <div class="modal-header" >
          <button type="button" class="close" data-dismiss="modal" style="color:white;">&times;</button>
          <h4 class="modal-title text-center form-title" style="color:white;">Create Account</h4>
        </div>
        <div class="modal-body padtrbl">

          <div class="login-box-body">
            <p class="login-box-msg">Sign in to start your session</p>
            <div class="form-group">
              <form name="" id="loginForm" method="post" action="signupltc.php">
                <div class="form-group has-feedback">
                  <!----- username -------------->
                  <input class="form-control" placeholder="Username" id="loginid" type="text" autocomplete="off" name="fname"/>
                  <span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 27px; top: 5px;" id="span_loginid"></span>
                  <!---Alredy exists  ! -->
                  <span class=" form-control-feedback glyphicon glyphicon-user" style="background-color: rgb(230,230,230);"></span>
                </div>
                <div class="form-group has-feedback">
                  <!----- mail -------------->
                  <input class="form-control" placeholder="E-mail"  type="text" autocomplete="off" name="email" />
                  <span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 27px; top: 5px;" id="span_loginid"></span>
                  <!---Alredy exists  ! -->
                  <span class="glyphicon glyphicon-envelope form-control-feedback" style="background-color: rgb(230,230,230);"></span>
                </div>
                <div class="form-group has-feedback">
                  <!----- password -------------->
                  <input class="form-control" placeholder="Password" id="loginpsw" type="password" autocomplete="off" name="pass"/>
                  <span style="display:none;font-weight:bold; position:absolute;color: grey;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 27px; top: 5px;" id="span_loginpsw"></span>
                  <!---Alredy exists  ! -->
                  <span class="glyphicon glyphicon-lock form-control-feedback" style="background-color: rgb(230,230,230);"></span>
                </div>
                <div class="row">
                  <div class="col-xs-12">
                    <div class="checkbox icheck">
                      <label>
                                <input type="checkbox" id="loginrem" > Remember Me
                              </label>
                    </div>
                  </div>
                  <div class="col-xs-12">
                    <button type="submit" class="btn btn-green btn-block btn-flat btn btn-primary" >Sign In</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
  </form>
  <script src="js/jquery.min.js"></script>
  <script src="js/jquery.easing.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/custom.js"></script>
  <script src="contactform/contactform.js"></script>
</body>
<?php
 if(isset($_GET['fname']))
 {
 $fname=$_GET["fname"];
 $password=$_GET["pwd"];
 //$gen=$_GET["gender"];
 
 if($fname=="" || $password=="")
 {
     echo"<center>"; 
         echo "<div class='card text-white bg-danger mb-3' style='max-width: 18rem;'><div class='card-header'>Login unsuccessfull!</div><div class='card-body'><h5 class='card-title'>All inputs are neccessary!</h5><p class='card-text'>All inputs are necessary  to log into your  account</p><button class='btn-secondary'><a href='http://localhost/test/'>Go Back</button></div></div>";
         echo "</center>";
 }
 else
 {
     
 if($_SERVER['REQUEST_METHOD']=="GET")//con establish
 {
 $localhost = "localhost";
 $username = "root";
 $passw = "";
 $db = "expdb";
 $conn = mysqli_connect($localhost,$username,$passw,$db);
 if(!$conn){
 echo "";
 }
 else
 {
 echo "";
 }
 $result=mysqli_query($conn,"select * from exptable where fname='$fname' and password='$password'")
         or die("FAILED!!".mysql_error());
   $row=mysqli_fetch_array($result);
   if($fname=='admin' and $password=='admin'){
    $url="http://localhost:88/E-Learning/adminpanel1.php";
		// header("Location:myaccount.php");
        echo "<script>location.href = '$url';</script>";
	}
     else
       {
      if($row['fname']==$fname and $row['password']==$password)
        {
           $_SESSION["username"]=$fname;  
           $url="http://localhost:88/E-Learning/home2.php";
           //header("location:home2.php");
           echo "<script>location.href = '$url';</script>";
    //         echo"<center>"; 
    //          echo "<div class='card text-white  mb-3' style='max-width: 18rem;'><button class='btn-success' style='height:10rem; font-size:2rem;'><a href='home2.php'>My Account</a></button></div>";
    //          echo "</center>";         
     }
     else
     {
     echo"<center>"; 
         echo "<div class='card text-white bg-danger mb-3' style='max-width: 18rem;'><div class='card-header'>Login Failed!</div><div class='card-body'><h5 class='card-title'>Username or Password is incorrect!!</h5><p class='card-text'>Looks like you have forgot your username or password </p><button class='btn-danger'><a href='forgotpassword.html'>Forgot Password!</a></button>&nbsp;&nbsp;&nbsp;&nbsp;<button class='btn-secondary'><a href='http://localhost/test/'>Go Back!</a></button></div></div>";
         echo "</center>"; 
     }
     }
 }}}
?>